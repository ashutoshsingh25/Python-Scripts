from flask import Flask
from py2neo import Graph

from app.config import SERVER_NAME, NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD

#  App configurations
app = Flask(__name__)
# app.config['SERVER_NAME'] = SERVER_NAME
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'

try:
    print("Connecting to Neo4j host:", NEO4J_URI)
    graph = Graph(uri=NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
    graph.run("Match () Return 1 Limit 1")
    print("Connection successful...")
except:
    print("Database error: Failed to connect to Neo4j. Please check database is running and credentials are correct.")
    exit(1)


# Initialize Application
@app.before_first_request
def before_first_request():
    print("Before first request!")


from app import routes
