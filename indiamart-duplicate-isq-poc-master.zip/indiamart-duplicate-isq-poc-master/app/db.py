from app import graph
from app.queries import *


def build_query(mcats_params, pc_ids_params, limit=25):
    if mcats_params and pc_ids_params:
        print("Building mcat and pc_id query")
        return duplicate_isq_query % (pc_ids_params, mcats_params, pc_ids_params, mcats_params, limit)
    elif mcats_params:
        print("Building mcat query")
        return duplicate_isq_query_only_mcat % (mcats_params, mcats_params, limit)
    elif pc_ids_params:
        print("Building pc_id query")
        return duplicate_isq_query_only_pc_item % (pc_ids_params, pc_ids_params, limit)
    else:
        raise RuntimeError('Params missing')


def build_list_param(str_list):
    if len(str_list) == 0:
        return None
    param_str = ''
    for str in str_list:
        if param_str != '':
            new_str = f',"{str}"'
        else:
            new_str = f'"{str}"'
        param_str = param_str + new_str
    param_str = f'[ {param_str}]'
    return param_str


def get_duplicate_isqs(mcats, pc_ids, limit):
    # Build list list string to create a Cypher query
    mcats_params = build_list_param(mcats)
    pc_ids_params = build_list_param(pc_ids)
    # Get query based on params
    query = build_query(mcats_params, pc_ids_params, limit)
    print("Query=", query)
    duplicate_isqs = graph.run(query).data()
    return duplicate_isqs


def get_unique_pc_item_ids(mcat):
    unique_pc_items = graph.run(unique_pc_items_query, parameters={'mcat_name': mcat}).evaluate()
    return unique_pc_items


def get_unique_pc_items_with_duplicate_isq(mcat):
    unique_pc_items = graph.run(unique_pc_items_with_duplicate_isq_query, parameters={'mcat_name': mcat}).evaluate()
    return unique_pc_items


def get_option_isq_map(mcat=None, pc_item_id=None, limit=5):
    global unique_pc_items
    if mcat:
        unique_pc_items = graph.run(option_isq_map_by_mcat_updated_query, parameters={'mcat_name': mcat, 'limit': limit}).data()
    elif pc_item_id:
        unique_pc_items = graph.run(option_isq_map_by_pc_item_id_updated_query, parameters={'pc_item_id': pc_item_id, 'limit': limit}).data()
    return unique_pc_items


def get_unique_isq_in_pc_item(pc_item_id=None):
    if pc_item_id:
        return graph.run(unique_isq_in_pc_item_query, parameters={'pc_item_id': pc_item_id}).evaluate()
    else:
        return 0


def get_duplicate_isq_in_pc_item(pc_item_id=None):
    if pc_item_id:
        return graph.run(duplicate_isq_in_pc_item_query, parameters={'pc_item_id': pc_item_id}).evaluate()
    else:
        return 0
