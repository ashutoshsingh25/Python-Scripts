from flask import render_template, request, jsonify
from werkzeug.exceptions import abort

from app import app, db


@app.route("/", methods=['GET'])
def index():
    return render_template('index.html', active_page='index')


@app.route("/duplicate-isq", methods=['POST'])
def get_duplicate_isq():
    if request.method == 'POST':
        # Get the fields
        mcat_names_field = request.form.get("mcatNames")
        pc_item_ids_field = request.form.get("pcItemIds")
        limit = request.form.get("limit")

        mcat_names = []
        pc_item_ids = []
        # Error if fields are missing
        if mcat_names_field and mcat_names_field.strip():
            mcat_names = [x.strip() for x in mcat_names_field.split(',')]

        if pc_item_ids_field and pc_item_ids_field.strip():
            pc_item_ids = [x.strip() for x in pc_item_ids_field.split(',')]

        if len(mcat_names) or len(pc_item_ids):
            print('Getting duplicate ISQs for: mcat_names=', mcat_names, "pc_item_ids=", pc_item_ids, "limit=", limit)
        else:
            return abort(400, "ERROR: mcatNames or pcItemIds missing!")

        duplicate_isqs = db.get_duplicate_isqs(mcat_names, pc_item_ids, limit)
        return jsonify(duplicate_isqs)
    else:
        return abort(405, "Method not allowed!")


@app.route("/statistics", methods=['GET'])
def statistics():
    return render_template('statistics.html', active_page='statistics')


@app.route("/duplicate-isq-statistics", methods=['POST'])
def get_duplicate_isq_statistics():
    if request.method == 'POST':
        # Get the fields
        mcat_name = request.form.get("mcatNames")
        pc_item_id = request.form.get("pcItemIds")
        limit = request.form.get("limit")
        if limit is None:
            limit = 5
        else:
            limit = int(limit)

        response = None
        # Error if fields are missing
        if mcat_name and mcat_name.strip():
            stat_type = 'mcat'
            mcat_name = mcat_name.strip()
            print('Getting Stats for: mcat_name=', mcat_name, 'limit=', limit)

            duplicate_option_isq_map = db.get_option_isq_map(mcat=mcat_name, limit=limit)
            unique_pc_item_ids = db.get_unique_pc_item_ids(mcat_name)
            unique_pc_items_with_duplicate_isq = db.get_unique_pc_items_with_duplicate_isq(mcat_name)

            response = {'unique_pc_item_ids': unique_pc_item_ids,
                        'unique_pc_items_with_duplicate_isq': unique_pc_items_with_duplicate_isq,
                        'duplicate_option_isq_map': duplicate_option_isq_map,
                        'stat_type': stat_type}
        elif pc_item_id and pc_item_id.strip():
            stat_type = 'pc_item'
            pc_item_id = pc_item_id.strip()
            print('Getting Stats for: pc_item_id=', pc_item_id, 'limit=', limit)

            duplicate_option_isq_map = db.get_option_isq_map(pc_item_id=pc_item_id, limit=limit)
            unique_isq_in_pc_item = db.get_unique_isq_in_pc_item(pc_item_id)
            duplicate_isq_in_pc_item = db.get_duplicate_isq_in_pc_item(pc_item_id)

            response = {'unique_isq_in_pc_item': unique_isq_in_pc_item,
                        'duplicate_isq_in_pc_item': duplicate_isq_in_pc_item,
                        'duplicate_option_isq_map': duplicate_option_isq_map,
                        'stat_type': stat_type}
        else:
            return abort(400, "ERROR: mcatName or pcItemId missing!")

        return jsonify(response)
    else:
        return abort(405, "Method not allowed!")
