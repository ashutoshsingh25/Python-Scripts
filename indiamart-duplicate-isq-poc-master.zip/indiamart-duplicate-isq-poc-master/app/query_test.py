from py2neo import Graph

from app import db

graph = Graph(password="Test@1234")

data = db.get_duplicate_isqs(None, None)
print(data)
