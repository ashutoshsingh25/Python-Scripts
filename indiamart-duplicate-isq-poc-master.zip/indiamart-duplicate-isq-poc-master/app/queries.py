"""
Duplicate ISQ Queries
"""

# Get duplicate ISQ by mcat and pc_item_id
duplicate_isq_query = '''
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
where p.pc_item_id in %s and m.mcat_name in %s
with m,r, p,i, i.options_desc as options
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r1]->(j:ISQ_Option)
where options = j.options_desc and type(r) <> type(r1) and id(r) > id(r1)
and p.pc_item_id in %s and m.mcat_name in %s
return m.mcat_name as MCAT_NAME, p.pc_item_id as PC_ITEM_ID,p.pc_item_name as ITEM_NAME
,i.options_desc as Option1,j.options_desc as Option2, type(r) as ISQ1, type(r1) as ISQ2
LIMIT %s
'''

# Get duplicate ISQ by mcat
duplicate_isq_query_only_mcat = '''
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
where m.mcat_name in %s
with m,r, p,i, i.options_desc as options
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r1]->(j:ISQ_Option)
where options = j.options_desc and type(r) <> type(r1) and id(r) > id(r1)
and m.mcat_name in %s
return m.mcat_name as MCAT_NAME, p.pc_item_id as PC_ITEM_ID,p.pc_item_name as ITEM_NAME
,i.options_desc as Option1,j.options_desc as Option2, type(r) as ISQ1, type(r1) as ISQ2
LIMIT %s
'''

# Get duplicate ISQ by pc_item_id
duplicate_isq_query_only_pc_item = '''
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
where p.pc_item_id in %s
with m,r, p,i, i.options_desc as options
match (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r1]->(j:ISQ_Option)
where options = j.options_desc and type(r) <> type(r1) and id(r) > id(r1)
and p.pc_item_id in %s
return m.mcat_name as MCAT_NAME, p.pc_item_id as PC_ITEM_ID,p.pc_item_name as ITEM_NAME
,i.options_desc as Option1,j.options_desc as Option2, type(r) as ISQ1, type(r1) as ISQ2
LIMIT %s
'''



"""
Stats Queries 
"""
# Get No of unique products in mcat
unique_pc_items_query = '''
MATCH (mcat:Glcat_Mcat)-[:HAS_PRODUCT]->(pc_item:Pc_Item)
WHERE mcat.mcat_name = $mcat_name
RETURN count(DISTINCT pc_item) as pc_item_count
'''

# Get No of unique ISQ in products
unique_isq_in_pc_item_query = '''
MATCH (p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE p.pc_item_id = $pc_item_id
WITH type(r) AS ISQ
RETURN COUNT(DISTINCT ISQ) AS unique_isq
'''

# Get No of duplicate ISQ in products
duplicate_isq_in_pc_item_query = '''
MATCH (p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE p.pc_item_id = $pc_item_id
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)
WITH collect(type_r)+collect(type(r1)) AS isqs
UNWIND isqs AS isq
RETURN COUNT(DISTINCT isq) AS duplicate_isq_cnt
'''

# Get No of unique products with duplicate ISQ in mcat
unique_pc_items_with_duplicate_isq_query = '''
MATCH (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE m.mcat_name = $mcat_name
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)
RETURN COUNT(DISTINCT p)
'''

option_isq_map_by_mcat_query = '''
MATCH (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE m.mcat_name = $mcat_name
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)
WITH options, 2*count(*) as option_cnt, collect(type_r)+collect(type(r1)) AS isqs
UNWIND isqs AS isq
WITH options, option_cnt, isq, count(isq) AS isq_cnt
ORDER BY option_cnt DESC, isq_cnt DESC
RETURN options, option_cnt, COLLECT({isq:isq, isq_cnt:isq_cnt})[..$limit] AS top_isqs 
'''


option_isq_map_by_mcat_updated_query = '''
MATCH (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE m.mcat_name = $mcat_name
WITH p, i.options_desc AS options, r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type(r) <> type(r1) AND id(r) > id(r1)
WITH options, 2*count(*) as option_cnt, collect(r)+collect(r1) AS isqs
UNWIND isqs AS isq
WITH options, option_cnt, type(isq) as isq_name, isq.type AS isq_type, count(isq) AS isq_cnt
ORDER BY option_cnt DESC, isq_cnt DESC
RETURN options, option_cnt, COLLECT({isq:isq_name, type:isq_type, isq_cnt:isq_cnt})[..$limit] AS top_isqs 
'''


option_isq_map_by_pc_item_id_query = '''
MATCH (p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE p.pc_item_id = $pc_item_id
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)
WITH options, 2*count(*) as option_cnt, collect(type_r)+collect(type(r1)) AS isqs
UNWIND isqs AS isq
WITH options, option_cnt, isq, count(isq) AS isq_cnt
ORDER BY option_cnt DESC, isq_cnt DESC
RETURN options, option_cnt, COLLECT({isq:isq, isq_cnt:isq_cnt})[..$limit] AS top_isqs
'''

option_isq_map_by_pc_item_id_updated_query = '''
MATCH (p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE p.pc_item_id = $pc_item_id
WITH p, i.options_desc AS options, r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type(r) <> type(r1) AND id(r) > id(r1)
WITH options, 2*count(*) as option_cnt, collect(r)+collect(r1) AS isqs
UNWIND isqs AS isq
WITH options, option_cnt, type(isq) as isq_name, isq.type AS isq_type, count(isq) AS isq_cnt
ORDER BY option_cnt DESC, isq_cnt DESC
RETURN options, option_cnt, COLLECT({isq:isq_name, type:isq_type, isq_cnt:isq_cnt})[..$limit] AS top_isqs
'''



# EXTRA: Intermediate queries
option_isq_map_query_V1 = '''
MATCH (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE m.mcat_name = $mcat_name
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)

WITH options, type_r AS isq1 where options="all"
RETURN collect(isq1)
'''

option_isq_map_query_V2 = '''
PROFILE 
MATCH (m:Glcat_Mcat)-[:HAS_PRODUCT]->(p:Pc_Item)-[r]->(i:ISQ_Option)
WHERE m.mcat_name =  $mcat_name
WITH p, i.options_desc AS options, type(r) AS type_r, id(r) AS id_r
MATCH (p)-[r1]->(j:ISQ_Option)
WHERE options = j.options_desc AND type_r <> type(r1) AND id_r > id(r1)

WITH options, count(*) as option_cnt, collect(type_r)+collect(type(r1)) AS isqs where options="all"
RETURN isqs
'''
