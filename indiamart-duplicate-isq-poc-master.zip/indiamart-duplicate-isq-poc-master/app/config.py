# Server Name
import os

SERVER_NAME = '0.0.0.0'

# Neo4j Config
NEO4J_USERNAME = os.environ.get('NEO4J_USERNAME', default='neo4j')
NEO4J_PASSWORD = os.environ.get('NEO4J_PASSWORD', default='123456')
NEO4J_URI = os.environ.get('NEO4J_URI', default='bolt://localhost:7687')
